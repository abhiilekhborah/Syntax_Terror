let map;
let marker;
let geocoder;
let selectedAddress = "";
let selectedLat;
let selectedLng;

function initMap(){

geocoder = new google.maps.Geocoder();

navigator.geolocation.getCurrentPosition(function(position){

selectedLat = position.coords.latitude;
selectedLng = position.coords.longitude;

const userLocation = {
lat: selectedLat,
lng: selectedLng
};

map = new google.maps.Map(document.getElementById("map"),{
zoom:15,
center:userLocation
});

marker = new google.maps.Marker({
position:userLocation,
map:map,
draggable:true
});

getAddress(userLocation);

marker.addListener("dragend",function(event){

selectedLat = event.latLng.lat();
selectedLng = event.latLng.lng();

getAddress(event.latLng);

});

});

}

function getAddress(location){

geocoder.geocode({location:location},function(results,status){

if(status==="OK"){

selectedAddress = results[0].formatted_address;

document.getElementById("address").innerText =
"Address: "+selectedAddress;

}

});

}

function submitReport(){

const description =
document.getElementById("description").value;

fetch("http://127.0.0.1:5000/report",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({
latitude:selectedLat,
longitude:selectedLng,
address:selectedAddress,
description:description
})

})
.then(res=>res.json())
.then(data=>{

alert("Report submitted successfully");

});

}
